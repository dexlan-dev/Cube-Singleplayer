#include<iostream>
#include<SFML/Graphics.hpp>
#include<SFML/OpenGL.hpp>
#include<SFML/Audio.hpp>
int main(){
sf::RenderWindow window(sf::VideoMode({800, 600}),"Cube Singleplayer Optimized");
window.setFramerateLimit(60);
sf::RectangleShape square(sf::Vector2f(150.f, 150.f));
square.setPosition({200.f, 200.f});
square.setFillColor(sf::Color::Green);
float speed=5.0;
while(window.isOpen()){
sf::Vector2f pos=square.getPosition();
if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W)){square.move({0.f, -speed});};
if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S)){square.move({0.f, speed});};
if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A)){square.move({-speed, 0.f});};
if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D)){square.move({speed, 0.f});};
window.clear(sf::Color(30,30,30));
window.draw(square);
window.display();
while(const std::optional event=window.pollEvent()){
if(event->is<sf::Event::Closed>()){window.close();};
}
}
return 0;
}